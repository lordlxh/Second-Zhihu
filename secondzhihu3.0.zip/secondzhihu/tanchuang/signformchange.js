
function start() {
document.getElementById('signform').style.display="";
document.getElementById('displaysign').style.display="none";
}

function signclose() {
    document.getElementById('signform').style.display="none";
    document.getElementById('displaysign').style.display="inline";
    document.getElementById('user').value='';
}

function clear(){
	document.getElementById('user').value='';
}

var PARAMTER_VALUE = null ;
function getParamter(paramName){
	if(!PARAMTER_VALUE){
		PARAMTER_VALUE=new Array();
		var paramStr=location.search.substring(1);
		var paramArr=paramStr.split("&");
		var len=paramArr.length;
		var tempArr;
		for(var i=0;i<len;i++){
		tempArr =paramArr[i].split("=");
		PARAMTER_VALUE[tempArr[0]]=tempArr[1];
		}
	}
	var paramValue=PARAMTER_VALUE[paramName];
	if(paramValue){
		return paramValue;
	}
}

function welcome(){
	var user=getParamter("uname");
	if(user=="undefined"||user==undefined){
		alert('请先登录');
	}
	else{
	alert("欢迎回来,"+user);}
	document.getElementById('invisible').value=user;
}
	
    function hotpoint(){
    var user=getParamter("uname");
    var url='http://localhost/secondzhihu/hotpoint.html?uname='+user;
    window.location.href = url;
}

function index(){
    var user=getParamter("uname");
    var url='http://localhost/secondzhihu/index1.php?uname='+user;
    window.location.href = url;
}

function enter(it){
        var user=getParamter("uname");
        url='http://localhost/secondzhihu/artical.php?uname='+user+'&qid='+it.id;
        if (window.XMLHttpRequest)
  			{// code for IE7+, Firefox, Chrome, Opera, Safari
  				xmlhttp=new XMLHttpRequest();
  		}
		else
  		{// code for IE6, IE5
  		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  			}
  			xmlhttp.open("GET","getcid.php?qid="+it.id,true);
  			//window.open("add.php?qid="+id.id);
			xmlhttp.send();
		xmlhttp.onreadystatechange=function()
  		{
  		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    		{
    		url+='&cid='+xmlhttp.responseText;
    		window.location.href=url;
    		}
  			}
        }



        function next(it){
        var user=getParamter("uname");
        url='http://localhost/secondzhihu/artical.php?uname='+user;
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
      }
    else
      {// code for IE6, IE5
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.open("GET","getnextqcid.php?cid="+it.id,true);
      xmlhttp.send();
      xmlhttp.onreadystatechange=function()
      {
      if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
        if(xmlhttp.responseText!="stupid"){
        url+=xmlhttp.responseText;
        window.location.href=url;}
        else{
          alert("已经是最后一个回答了");
        }
        }
        }
        }

        function pre(it){
        var user=getParamter("uname");
        url='http://localhost/secondzhihu/artical.php?uname='+user;
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
      }
    else
      {// code for IE6, IE5
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.open("GET","getpreqcid.php?cid="+it.id,true);
      xmlhttp.send();
      xmlhttp.onreadystatechange=function()
      {
      if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
        if(xmlhttp.responseText!="stupid"){
        url+=xmlhttp.responseText;
        window.location.href=url;}
        else{
          alert("已经是最后一个回答了");
        }
        }
        }
        }