<?php  //注册
	function safe_input($data){
		$data=trim("$data");
		$data=stripcslashes("$data");
		$data=htmlspecialchars("$data");
		return $data;
	}
	$connect=mysqli_connect("localhost","root","");
	if(!$connect){
		die('Could not connect: ' . mysqli_error($connect));
	}
	if(!mysqli_select_db($connect,"yongHu")){//如果数据库不存在
		if(!mysqli_query($connect,"CREATE DATABASE yongHu")){//如果创建失败
			die('Error creating database: ' . mysqli_error($connect));
		}
	}
//数据库存在或不存在但创建成功
	$data=array();$biao=mysqli_query($connect,"show tables;");
	while($row=mysqli_fetch_assoc($biao)){
		$data+=$row;
	}unset($biao,$row);
	if(!in_array(strtolower("contact"), $data)){//如果账号列表不存在
		$sql="CREATE TABLE contact (
		uid int NOT NULL AUTO_INCREMENT,
		PRIMARY KEY(uid),
		cname varchar(20),
		email varchar(25),
		csubject varchar(20),
		phone varchar(15),
		cmessage varchar(800)
		)";
		if(!mysqli_query($connect,$sql)){die('Error creating table: ' . mysqli_error($connect));}
	}unset($data);
//列表存在,注册用户账号信息
	$sign=1;
	$cname=safe_input($_POST["name"]);
	$email=safe_input($_POST["email"]);
	$csubject=safe_input($_POST["subject"]);
	$phone=safe_input($_POST["phone"]);
	$cmessage=safe_input($_POST["message"]);
	if($sign==1){
		$sql="INSERT INTO contact (cname,email,csubject,phone,cmessage) VALUES ('$cname', '$email', '$csubject','$phone','$cmessage')";
		if(!mysqli_query($connect,$sql)){die('Error creating contact: ' . mysqli_error($connect));}
	echo "<script  language = 'javascript' type = 'text/javascript'> alert('发送成功');window.location.href = 'http://localhost/secondzhihu/contact.html';</script>";}
	mysqli_close($connect);

?>