from django.shortcuts import render,redirect,reverse
from show import views
# Create your views here.
def indexproc(request):
    return render(request,"index.html")

def show(request):
    return redirect(reverse(views.showproc))