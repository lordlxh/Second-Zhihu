from django.shortcuts import render,redirect,reverse
from home import views
# Create your views here.
def showproc(request):
    return render(request,"marketing.html")

def index(request):
    return redirect(reverse(views.indexproc))